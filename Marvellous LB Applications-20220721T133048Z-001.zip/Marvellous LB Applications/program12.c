// Program to display 5 times Hello on screen

#include<stdio.h>

// Demonstration of SEQUANCE

void Display();                 // Declaration

int main()
{
    Display();                  // Function call
    
    return 0;
}

void Display()              // Defination
{
    printf("Hello\n");
    printf("Hello\n");
    printf("Hello\n");
    printf("Hello\n");
    printf("Hello\n");
}