 // Template for probplems on pattern printing

#include<iostream>
using namespace std;

class Pattern
{
    private:
        int iRow, iCol;

    public:
        Pattern(int a, int b)
        {
            this->iRow = a;
            this->iCol = b;
        }

        public void DisplayPattern()
        {
                // Logic
        }
};

int main()
{
    Pattern obj(__, ___);
    obj.DisplayPattern();

    return 0;
}