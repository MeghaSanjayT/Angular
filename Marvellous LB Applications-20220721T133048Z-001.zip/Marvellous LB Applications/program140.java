import java.lang.*;
import java.util.*;

class program140
{
    public static void main(String b[])
    {
        System.out.println("Jay Ganesh");
    }
}