import java.lang.*;
import java.util.*;

class Bitwise
{

}

class program191
{
    public static void main(String arg[])
    {
        Scanner sobj = new Scanner(System.in);

        System.out.println("Enter number ");
        int value = sobj.nextInt();

        Bitwise bobj = new Bitwise();

    }
}