#include<stdio.h>

int main()
{
	printf("Jay Ganesh...\n");

	return 0;
}

// gcc program1.c  -o  Myexe

// Windows
// Myexe

// Linux / MacOS
// ./Myexe