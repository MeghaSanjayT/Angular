// Program to display 5 times Hello on screen

#include<stdio.h>

// Demonstration of SEQUANCE
void Display()
{
    printf("Hello\n");
    printf("Hello\n");
    printf("Hello\n");
    printf("Hello\n");
    printf("Hello\n");
}

int main()
{
    Display();

    return 0;
}