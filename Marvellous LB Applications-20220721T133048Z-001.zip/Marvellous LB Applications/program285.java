import java.lang.*;
import java.util.*;

class program285
{
    public static void main(String arg[])
    {

    }
}