#include<stdio.h>                           // Header file inclustion

typedef unsigned long int ULONG;        // typedef

ULONG Power(int iNo1, int iNo2);        // Function prototype
