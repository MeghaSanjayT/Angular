// Write a program to perform addition of 2 numbers

#include<stdio.h>

 int main()
 {
    int i = 10;
    int j = 20;
    int k = 0;

    k = i + j;

    printf("Addition is : %d\n",k);

    return 0;
 }