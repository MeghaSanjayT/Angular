#include<iostream>
using namespace std;

int main()
{
    char Arr[] = "Hello";

    cout<<Arr;
    printf("%s\n",Arr);

    return 0;
}
