// Program to display 1 to 5 on screen
// Output   1   2   3   4   5

#include<stdio.h>

void Display()
{
    printf("1\n");
    printf("2\n");
    printf("3\n");
    printf("4\n");
    printf("5\n");
}

int main()
{
    Display();

    return 0;
}