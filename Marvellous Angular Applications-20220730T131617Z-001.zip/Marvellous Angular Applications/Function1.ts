function fun() : void          // Function defination
{
    console.log("Inside fun");
}

fun();      // Function call

/*
    void fun()
    {
        printf("Inside fun");
        cout<<"Inside fun";
        System.out.println("Inside fun");
    }
*/