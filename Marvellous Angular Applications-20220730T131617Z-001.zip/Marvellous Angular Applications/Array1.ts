// int Arr[5] = {10,20,30,40,50};               // C, C++, Java, C#

// Arr is one dimentional array which contains 5 elements each element is of type number.
var Arr : number[] = [10,20,30,40,50];

console.log("Length of array is : "+Arr.length);
console.log("First element is : "+Arr[0]);
console.log("Second element is : "+Arr[1]);

console.log("Elements from array ara : ");
var i : number = 0;

//       1             2                3
for(i = 0; i < Arr.length; i++)
{
        console.log(Arr[i]);    // 4
}