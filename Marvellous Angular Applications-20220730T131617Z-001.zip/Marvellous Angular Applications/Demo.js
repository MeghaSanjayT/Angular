var no = 11; // int no = 11;
var str = "Jay Ganesh...";
console.log(str); // Display on console
console.log(no);
