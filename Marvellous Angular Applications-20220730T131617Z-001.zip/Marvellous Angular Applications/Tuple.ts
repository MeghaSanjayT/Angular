// Tuple is collection of elements having any type of data type
var Arr = [10,"Hello",true,90.78];

console.log("Length of array is : "+Arr.length);
console.log("First element is : "+Arr[0]);
console.log("Second element is : "+Arr[1]);

console.log("Elements from array ara : ");
var i : number = 0;

for(i = 0; i < Arr.length; i++)
{
        console.log(Arr[i]);
}