function Display(value : number) : void
{
    console.log("Parameter is : "+value);
}

var no : number = 11;
Display(no);    